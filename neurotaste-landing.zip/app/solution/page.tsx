import Image from "next/image"
import { ArrowRight, Brain, Lightbulb, Zap } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function Solution() {
  return (
    <main className="flex-1">
      {/* Hero Section */}
      <section className="py-20 bg-slate-900">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <h1 className="text-3xl md:text-5xl font-bold text-white mb-6">Our Solution: NeuroTaste</h1>
            <p className="text-lg text-slate-300">
              Revolutionizing taste perception through cutting-edge neural interface technology.
            </p>
          </div>

          {/* The Problem & Solution */}
          <div className="grid md:grid-cols-2 gap-12 mb-20">
            <div className="bg-slate-800 p-8 rounded-xl">
              <div className="w-12 h-12 bg-red-900/30 rounded-full flex items-center justify-center mb-6">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-6 w-6 text-red-400"
                >
                  <path d="M8 2h8"></path>
                  <path d="M12 14v7"></path>
                  <path d="M9 18h6"></path>
                  <path d="M12 2v7"></path>
                  <path d="M8 9h8"></path>
                  <path d="M18 9a6 6 0 0 1-6 6 6 6 0 0 1-6-6"></path>
                </svg>
              </div>
              <h2 className="text-2xl font-bold text-white mb-4">The Problem</h2>
              <p className="text-slate-300 mb-4">
                Taste perception is limited by our biological capabilities. Many people face challenges with:
              </p>
              <ul className="space-y-2 text-slate-300 mb-6">
                <li className="flex items-start gap-2">
                  <span className="text-red-400">•</span> Dietary restrictions that limit food enjoyment
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-red-400">•</span> Taste disorders affecting quality of life
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-red-400">•</span> Inability to experience the full spectrum of flavors
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-red-400">•</span> Sensory limitations in food and beverage experiences
                </li>
              </ul>
              <p className="text-slate-300">
                Current solutions rely on chemical additives or substitutes that often fail to replicate authentic taste
                experiences.
              </p>
            </div>

            <div className="bg-slate-800 p-8 rounded-xl">
              <div className="w-12 h-12 bg-green-900/30 rounded-full flex items-center justify-center mb-6">
                <Lightbulb className="h-6 w-6 text-green-400" />
              </div>
              <h2 className="text-2xl font-bold text-white mb-4">Our Solution</h2>
              <p className="text-slate-300 mb-4">
                NeuroTaste is a revolutionary neural interface technology that enhances and transforms taste perception
                by directly interfacing with the brain's sensory pathways.
              </p>
              <ul className="space-y-2 text-slate-300 mb-6">
                <li className="flex items-start gap-2">
                  <span className="text-green-400">•</span> Non-invasive neural stimulation technology
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-400">•</span> Personalized taste profiles for individual preferences
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-400">•</span> Enhanced flavor perception beyond biological limitations
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-400">•</span> Digital taste simulation without chemical additives
                </li>
              </ul>
              <p className="text-slate-300">
                Our technology bridges neuroscience and culinary arts to create unprecedented taste experiences that are
                customizable, accessible, and transformative.
              </p>
            </div>
          </div>

          {/* How It Works */}
          <div className="mb-20">
            <h2 className="text-3xl font-bold text-white mb-10 text-center">How NeuroTaste Works</h2>
            <div className="grid md:grid-cols-3 gap-8">
              <div className="bg-slate-800 p-8 rounded-xl relative">
                <div className="absolute -top-5 left-1/2 transform -translate-x-1/2 w-10 h-10 rounded-full bg-green-600 flex items-center justify-center text-white font-bold">
                  1
                </div>
                <div className="pt-4">
                  <h3 className="text-xl font-semibold text-white mb-4 text-center">Neural Mapping</h3>
                  <p className="text-slate-300">
                    Our device first creates a personalized map of your taste receptors and neural pathways, identifying
                    your unique sensory profile and preferences.
                  </p>
                </div>
              </div>

              <div className="bg-slate-800 p-8 rounded-xl relative">
                <div className="absolute -top-5 left-1/2 transform -translate-x-1/2 w-10 h-10 rounded-full bg-green-600 flex items-center justify-center text-white font-bold">
                  2
                </div>
                <div className="pt-4">
                  <h3 className="text-xl font-semibold text-white mb-4 text-center">Sensory Translation</h3>
                  <p className="text-slate-300">
                    The system translates desired taste experiences into precise neural signals that can be interpreted
                    by your brain's sensory processing centers.
                  </p>
                </div>
              </div>

              <div className="bg-slate-800 p-8 rounded-xl relative">
                <div className="absolute -top-5 left-1/2 transform -translate-x-1/2 w-10 h-10 rounded-full bg-green-600 flex items-center justify-center text-white font-bold">
                  3
                </div>
                <div className="pt-4">
                  <h3 className="text-xl font-semibold text-white mb-4 text-center">Neural Stimulation</h3>
                  <p className="text-slate-300">
                    Using non-invasive stimulation, NeuroTaste activates specific neural pathways to create, enhance, or
                    modify taste perceptions in real-time.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Key Features */}
          <div className="mb-20">
            <h2 className="text-3xl font-bold text-white mb-10 text-center">Key Features</h2>
            <div className="grid md:grid-cols-2 gap-8">
              <div className="bg-slate-800 p-8 rounded-xl flex gap-6">
                <div className="w-12 h-12 bg-green-900/30 rounded-full flex items-center justify-center flex-shrink-0">
                  <Brain className="h-6 w-6 text-green-400" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-white mb-2">Non-Invasive Technology</h3>
                  <p className="text-slate-300">
                    Our solution requires no implants or invasive procedures, making it accessible and comfortable for
                    everyday use.
                  </p>
                </div>
              </div>

              <div className="bg-slate-800 p-8 rounded-xl flex gap-6">
                <div className="w-12 h-12 bg-green-900/30 rounded-full flex items-center justify-center flex-shrink-0">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-6 w-6 text-green-400"
                  >
                    <path d="M12 22a7 7 0 0 0 7-7c0-2-1-3.9-3-5.5s-3.5-4-4-6.5c-.5 2.5-2 4.9-4 6.5C6 11.1 5 13 5 15a7 7 0 0 0 7 7z"></path>
                  </svg>
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-white mb-2">Flavor Enhancement</h3>
                  <p className="text-slate-300">
                    Amplify existing flavors to experience subtle notes and dimensions previously imperceptible to your
                    taste buds.
                  </p>
                </div>
              </div>

              <div className="bg-slate-800 p-8 rounded-xl flex gap-6">
                <div className="w-12 h-12 bg-green-900/30 rounded-full flex items-center justify-center flex-shrink-0">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-6 w-6 text-green-400"
                  >
                    <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"></path>
                    <polyline points="14 2 14 8 20 8"></polyline>
                  </svg>
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-white mb-2">Customizable Profiles</h3>
                  <p className="text-slate-300">
                    Create and save personalized taste profiles for different occasions, dietary needs, or experimental
                    flavor combinations.
                  </p>
                </div>
              </div>

              <div className="bg-slate-800 p-8 rounded-xl flex gap-6">
                <div className="w-12 h-12 bg-green-900/30 rounded-full flex items-center justify-center flex-shrink-0">
                  <Zap className="h-6 w-6 text-green-400" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-white mb-2">Real-Time Adaptation</h3>
                  <p className="text-slate-300">
                    The system learns from your feedback and adjusts in real-time to optimize your taste experience with
                    each use.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Prototype Section */}
          <div className="bg-slate-800 rounded-2xl p-10 mb-20">
            <h2 className="text-3xl font-bold text-white mb-8 text-center">Our Prototype</h2>
            <div className="flex flex-col lg:flex-row items-center gap-12">
              <div className="lg:w-1/2">
                <div className="relative w-full aspect-square max-w-md mx-auto border-4 border-green-500 rounded-2xl overflow-hidden">
                  <Image
                    src="/placeholder.svg?height=600&width=600"
                    alt="NeuroTaste prototype"
                    width={600}
                    height={600}
                    className="object-cover"
                  />
                  <div className="absolute inset-0 flex items-center justify-center bg-slate-900/70">
                    <p className="text-white text-xl font-bold">Prototype Image Coming Soon</p>
                  </div>
                </div>
              </div>
              <div className="lg:w-1/2">
                <h3 className="text-2xl font-bold text-white mb-4">The NeuroTaste Prototype</h3>
                <p className="text-slate-300 mb-4">
                  Our current prototype demonstrates the core functionality of the NeuroTaste system, showcasing how
                  neural stimulation can enhance and modify taste perception in real-time.
                </p>
                <p className="text-slate-300 mb-6">
                  The device uses a combination of non-invasive neural interface technology and advanced algorithms to
                  create a seamless bridge between digital signals and your brain's taste perception centers.
                </p>
                <h4 className="text-xl font-semibold text-white mb-3">Technical Specifications:</h4>
                <ul className="space-y-2 text-slate-300 mb-6">
                  <li className="flex items-start gap-2">
                    <span className="text-green-400">•</span> Compact, wearable form factor
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-green-400">•</span> Wireless connectivity for seamless control
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-green-400">•</span> Advanced neural mapping capabilities
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-green-400">•</span> Real-time taste profile adjustments
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-green-400">•</span> Long-lasting battery life for extended use
                  </li>
                </ul>
                <Button className="bg-green-600 hover:bg-green-700 flex items-center gap-2">
                  Learn More About Our Technology <ArrowRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>

          {/* Applications */}
          <div className="mb-20">
            <h2 className="text-3xl font-bold text-white mb-10 text-center">Applications</h2>
            <div className="grid md:grid-cols-3 gap-8">
              <div className="bg-slate-800 p-8 rounded-xl">
                <h3 className="text-xl font-semibold text-white mb-4">Culinary Innovation</h3>
                <p className="text-slate-300">
                  Chefs and food innovators can create entirely new dining experiences by enhancing and transforming
                  flavor profiles in ways previously impossible.
                </p>
              </div>

              <div className="bg-slate-800 p-8 rounded-xl">
                <h3 className="text-xl font-semibold text-white mb-4">Medical Applications</h3>
                <p className="text-slate-300">
                  Help individuals with taste disorders, those undergoing chemotherapy, or people with dietary
                  restrictions enjoy a fuller range of taste experiences.
                </p>
              </div>

              <div className="bg-slate-800 p-8 rounded-xl">
                <h3 className="text-xl font-semibold text-white mb-4">Sustainable Eating</h3>
                <p className="text-slate-300">
                  Enhance the taste of sustainable food alternatives, making environmentally-friendly choices more
                  appealing and enjoyable.
                </p>
              </div>
            </div>
          </div>

          {/* CTA */}
          <div className="text-center">
            <h2 className="text-2xl md:text-3xl font-bold text-white mb-6">Ready to Experience the Future of Taste?</h2>
            <Button asChild className="bg-green-600 hover:bg-green-700 px-8 py-6">
              <a href="/contact">Contact Us</a>
            </Button>
          </div>
        </div>
      </section>
    </main>
  )
}
