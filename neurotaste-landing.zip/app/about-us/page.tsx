import Image from "next/image"
import { Github, Linkedin, Twitter } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function AboutUs() {
  const team = [
    {
      name: "Avantika Subudhi",
      role: "Co-Founder",
      bio: "High school student passionate about neuroscience and sensory perception. Leading research on taste receptor technology and neural interfaces.",
      image: "/placeholder.svg?height=400&width=400",
    },
    {
      name: "Suditi Gupta",
      role: "Co-Founder",
      bio: "High school student with expertise in biomedical engineering and neural interface design. Developing innovative approaches to sensory augmentation.",
      image: "/placeholder.svg?height=400&width=400",
    },
  ]

  return (
    <main className="flex-1">
      <section className="py-20 bg-slate-900">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <h1 className="text-3xl md:text-5xl font-bold text-white mb-6">About Us</h1>
            <p className="text-lg text-slate-300">
              Meet the visionaries behind NeuroTaste who are redefining the boundaries of taste perception.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-12 max-w-4xl mx-auto mb-20">
            {team.map((member, index) => (
              <div key={index} className="flex flex-col items-center">
                <div className="relative w-48 h-48 mb-6">
                  <Image
                    src={member.image || "/placeholder.svg"}
                    alt={member.name}
                    fill
                    className="object-cover rounded-full border-4 border-green-500"
                  />
                </div>
                <h3 className="text-2xl font-bold text-white mb-1">{member.name}</h3>
                <p className="text-green-400 mb-4">{member.role}</p>
                <p className="text-slate-300 text-center mb-6">{member.bio}</p>
                <div className="flex gap-4">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="rounded-full text-slate-300 hover:text-white hover:bg-slate-800"
                  >
                    <Linkedin className="h-5 w-5" />
                    <span className="sr-only">LinkedIn</span>
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="rounded-full text-slate-300 hover:text-white hover:bg-slate-800"
                  >
                    <Twitter className="h-5 w-5" />
                    <span className="sr-only">Twitter</span>
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="rounded-full text-slate-300 hover:text-white hover:bg-slate-800"
                  >
                    <Github className="h-5 w-5" />
                    <span className="sr-only">GitHub</span>
                  </Button>
                </div>
              </div>
            ))}
          </div>

          {/* Mission Section */}
          <div className="bg-slate-800 rounded-2xl p-10 mb-12">
            <h2 className="text-2xl md:text-3xl font-bold text-white mb-6">Our Mission</h2>
            <p className="text-slate-300 text-lg mb-6">
              At NeuroTaste, we're on a mission to revolutionize how humans experience taste. We believe that by
              bridging neuroscience and culinary arts, we can unlock new dimensions of flavor that enhance human
              experience, address dietary challenges, and create more sustainable food systems.
            </p>
            <p className="text-slate-300 text-lg">
              We're committed to making advanced taste technology accessible, ethical, and beneficial for everyone. Our
              goal is to create a future where taste is not limited by biology but enhanced by technology.
            </p>
          </div>

          {/* Values Section */}
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-slate-900 p-8 rounded-xl">
              <h3 className="text-xl font-semibold text-white mb-3">Innovation</h3>
              <p className="text-slate-300">
                We push the boundaries of what's possible in sensory technology, constantly exploring new approaches and
                solutions to enhance the human experience of taste.
              </p>
            </div>

            <div className="bg-slate-900 p-8 rounded-xl">
              <h3 className="text-xl font-semibold text-white mb-3">Accessibility</h3>
              <p className="text-slate-300">
                We believe that revolutionary technology should be accessible to all. We're committed to developing
                solutions that can benefit people from all walks of life.
              </p>
            </div>

            <div className="bg-slate-900 p-8 rounded-xl">
              <h3 className="text-xl font-semibold text-white mb-3">Ethical Innovation</h3>
              <p className="text-slate-300">
                We prioritize ethical considerations in all our research and development, ensuring our technology
                respects human autonomy and enhances well-being.
              </p>
            </div>
          </div>

          {/* Culture Section */}
          <div className="mt-16 bg-slate-800 rounded-2xl p-10">
            <h2 className="text-2xl md:text-3xl font-bold text-white mb-6">Our Culture</h2>
            <p className="text-slate-300 text-lg mb-6">
              As high school students with a passion for innovation, we've built NeuroTaste on a foundation of
              curiosity, collaboration, and determination. We believe that age is not a barrier to creating meaningful
              change.
            </p>
            <p className="text-slate-300 text-lg mb-6">Our team culture embraces:</p>
            <ul className="list-disc pl-6 text-slate-300 text-lg space-y-2 mb-6">
              <li>Bold thinking and creative problem-solving</li>
              <li>Continuous learning and knowledge sharing</li>
              <li>Resilience in the face of challenges</li>
              <li>Collaboration with experts across disciplines</li>
              <li>Celebrating both successes and failures as opportunities to grow</li>
            </ul>
            <p className="text-slate-300 text-lg">
              We're building more than just technology—we're creating a community of innovators who believe in the power
              of sensory enhancement to improve lives.
            </p>
          </div>
        </div>
      </section>
    </main>
  )
}
