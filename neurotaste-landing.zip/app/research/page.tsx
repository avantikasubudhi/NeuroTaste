import Image from "next/image"
import { Button } from "@/components/ui/button"

export default function Research() {
  const researchAreas = [
    {
      title: "Taste Receptor Mapping",
      description:
        "Identifying and categorizing neural pathways associated with different taste experiences to create a comprehensive taste map.",
      image: "/placeholder.svg?height=300&width=500",
    },
    {
      title: "Non-Invasive Neural Interfaces",
      description:
        "Developing technologies that can stimulate taste receptors without requiring invasive procedures or implants.",
      image: "/placeholder.svg?height=300&width=500",
    },
    {
      title: "Personalized Taste Profiles",
      description:
        "Creating algorithms that learn from individual preferences and physiological responses to tailor taste experiences.",
      image: "/placeholder.svg?height=300&width=500",
    },
  ]

  return (
    <main className="flex-1">
      <section className="py-20 bg-slate-900">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <h1 className="text-3xl md:text-5xl font-bold text-white mb-6">Our Research</h1>
            <p className="text-lg text-slate-300">
              Exploring the frontiers of taste perception and neural interfaces to create revolutionary sensory
              experiences.
            </p>
          </div>

          <div className="space-y-20">
            {researchAreas.map((area, index) => (
              <div
                key={index}
                className={`flex flex-col ${index % 2 === 0 ? "lg:flex-row" : "lg:flex-row-reverse"} items-center gap-12`}
              >
                <div className="lg:w-1/2">
                  <div className="relative w-full aspect-video max-w-lg mx-auto">
                    <Image
                      src={area.image || "/placeholder.svg"}
                      alt={area.title}
                      width={500}
                      height={300}
                      className="object-cover rounded-2xl shadow-lg"
                    />
                  </div>
                </div>
                <div className="lg:w-1/2">
                  <h2 className="text-2xl md:text-3xl font-bold text-white mb-4">{area.title}</h2>
                  <p className="text-lg text-slate-300 mb-6">{area.description}</p>
                  <p className="text-slate-300 mb-6">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod, nisl vel ultricies lacinia,
                    nisl nisl aliquam nisl, eget aliquam nisl nisl sit amet nisl. Sed euismod, nisl vel ultricies
                    lacinia, nisl nisl aliquam nisl, eget aliquam nisl nisl sit amet nisl.
                  </p>
                  <Button className="bg-green-600 hover:bg-green-700">Learn More</Button>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-20 bg-slate-800 rounded-2xl p-10">
            <h2 className="text-2xl md:text-3xl font-bold text-white mb-6">Future Research Directions</h2>
            <p className="text-slate-300 text-lg mb-6">
              As we continue to explore the frontiers of taste perception, we're excited about several emerging areas of
              research:
            </p>
            <ul className="list-disc pl-6 text-slate-300 text-lg space-y-4 mb-6">
              <li>
                Integration of olfactory stimulation with taste enhancement for a more holistic sensory experience
              </li>
              <li>Applications in dietary modification for individuals with health conditions or restrictions</li>
              <li>Cross-modal sensory integration to understand how taste interacts with other senses</li>
              <li>Development of more compact and accessible neural interface technologies</li>
            </ul>
            <p className="text-slate-300 text-lg">
              We're committed to pushing the boundaries of what's possible in taste perception and neural interfaces,
              always with a focus on creating technologies that enhance human experience in ethical and meaningful ways.
            </p>
          </div>

          <div className="mt-20 text-center">
            <h2 className="text-2xl md:text-3xl font-bold text-white mb-6">Interested in Collaborating?</h2>
            <p className="text-lg text-slate-300 max-w-2xl mx-auto mb-8">
              We're always looking for partners, advisors, and collaborators who share our vision for the future of
              taste technology.
            </p>
            <Button asChild className="bg-green-600 hover:bg-green-700 px-8 py-6">
              <a href="/contact">Contact Us</a>
            </Button>
          </div>
        </div>
      </section>
    </main>
  )
}
