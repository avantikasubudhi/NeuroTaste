import Image from "next/image"
import Link from "next/link"
import { Brain, Sparkles, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative bg-gradient-to-r from-slate-900 to-slate-800 min-h-[calc(100vh-5rem)]">
          <div className="container h-full flex flex-col lg:flex-row items-center py-20 lg:py-32">
            <div className="lg:w-1/2 lg:pr-12 mb-12 lg:mb-0">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white leading-tight">
                Reimagining
                <span className="text-green-500 block mt-2">Taste Perception</span>
              </h1>
              <p className="mt-6 text-lg text-slate-300 max-w-xl">
                Pioneering neural interfaces that transform how we experience flavor, creating new sensory dimensions
                beyond traditional taste.
              </p>
              <div className="mt-10 flex flex-col sm:flex-row gap-4">
                <Button asChild className="bg-green-600 hover:bg-green-700 px-8 py-6">
                  <Link href="/technology">Explore Technology</Link>
                </Button>
                <Button
                  asChild
                  variant="outline"
                  className="border-green-600 text-green-400 hover:bg-slate-800 px-8 py-6"
                >
                  <Link href="/about-us">About Us</Link>
                </Button>
              </div>
            </div>
            <div className="lg:w-1/2 relative">
              <div className="relative w-full aspect-square max-w-md mx-auto">
                <Image
                  src="/placeholder.svg?height=600&width=600"
                  alt="Neural taste interface visualization"
                  width={600}
                  height={600}
                  className="object-cover rounded-2xl shadow-xl"
                  priority
                />
                <div className="absolute -bottom-6 -left-6 bg-slate-800 p-4 rounded-xl shadow-lg">
                  <div className="flex items-center gap-2">
                    <Sparkles className="h-5 w-5 text-green-500" />
                    <span className="text-sm font-medium text-white">5x Taste Enhancement</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-slate-950 to-transparent" />
        </section>

        {/* Feature Highlights */}
        <section className="py-20 bg-slate-950">
          <div className="container">
            <div className="max-w-3xl mx-auto text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-white">Revolutionizing Sensory Experience</h2>
              <p className="mt-4 text-lg text-slate-300">
                NeuroTaste bridges neuroscience and gastronomy to create unprecedented taste experiences.
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              <div className="bg-slate-900 p-8 rounded-xl">
                <div className="w-12 h-12 bg-green-900/50 rounded-full flex items-center justify-center mb-6">
                  <Brain className="h-6 w-6 text-green-500" />
                </div>
                <h3 className="text-xl font-semibold text-white mb-3">Neural Interface</h3>
                <p className="text-slate-300 mb-6">
                  Our proprietary technology directly interfaces with taste receptors and neural pathways.
                </p>
                <Link href="/technology" className="inline-flex items-center text-green-400 hover:text-green-300">
                  Learn more <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </div>

              <div className="bg-slate-900 p-8 rounded-xl">
                <div className="w-12 h-12 bg-green-900/50 rounded-full flex items-center justify-center mb-6">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-6 w-6 text-green-500"
                  >
                    <path d="M12 22a7 7 0 0 0 7-7c0-2-1-3.9-3-5.5s-3.5-4-4-6.5c-.5 2.5-2 4.9-4 6.5C6 11.1 5 13 5 15a7 7 0 0 0 7 7z"></path>
                  </svg>
                </div>
                <h3 className="text-xl font-semibold text-white mb-3">Flavor Enhancement</h3>
                <p className="text-slate-300 mb-6">
                  Experience familiar foods with heightened intensity and previously imperceptible dimensions.
                </p>
                <Link href="/research" className="inline-flex items-center text-green-400 hover:text-green-300">
                  Learn more <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </div>

              <div className="bg-slate-900 p-8 rounded-xl">
                <div className="w-12 h-12 bg-green-900/50 rounded-full flex items-center justify-center mb-6">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-6 w-6 text-green-500"
                  >
                    <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"></path>
                    <polyline points="14 2 14 8 20 8"></polyline>
                  </svg>
                </div>
                <h3 className="text-xl font-semibold text-white mb-3">Taste Profiles</h3>
                <p className="text-slate-300 mb-6">
                  Customize your sensory experience with programmable taste profiles for your unique preferences.
                </p>
                <Link href="/technology" className="inline-flex items-center text-green-400 hover:text-green-300">
                  Learn more <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-green-700">
          <div className="container text-center">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">Join the Taste Revolution</h2>
            <p className="text-lg text-green-100 max-w-2xl mx-auto mb-10">
              Discover how NeuroTaste is transforming the future of sensory experiences and culinary innovation.
            </p>
            <Button asChild className="bg-white text-green-700 hover:bg-green-50 px-8 py-6 text-lg">
              <Link href="/contact">Contact Us</Link>
            </Button>
          </div>
        </section>
      </main>
    </div>
  )
}
