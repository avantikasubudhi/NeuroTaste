import Image from "next/image"
import { ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function Technology() {
  return (
    <main className="flex-1">
      <section className="py-20 bg-slate-900">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <h1 className="text-3xl md:text-5xl font-bold text-white mb-6">Our Technology</h1>
            <p className="text-lg text-slate-300">
              Discover the science behind NeuroTaste's revolutionary approach to taste perception.
            </p>
          </div>

          <div className="flex flex-col lg:flex-row items-center gap-12 mb-20">
            <div className="lg:w-1/2">
              <div className="relative w-full aspect-video max-w-lg mx-auto">
                <Image
                  src="/placeholder.svg?height=450&width=800"
                  alt="NeuroTaste technology visualization"
                  width={800}
                  height={450}
                  className="object-cover rounded-2xl shadow-lg"
                />
              </div>
            </div>
            <div className="lg:w-1/2">
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">The Science of NeuroTaste</h2>
              <p className="text-lg text-slate-300 mb-6">
                Our breakthrough technology creates a seamless bridge between digital signals and your brain's taste
                perception centers.
              </p>
              <ul className="space-y-4">
                {[
                  "Non-invasive neural interfaces that stimulate specific taste receptors",
                  "AI-powered flavor mapping that adapts to individual preferences",
                  "Molecular-level taste simulation without chemical additives",
                  "Real-time sensory feedback and adjustment",
                ].map((item, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <div className="mt-1 h-5 w-5 rounded-full bg-green-900/50 flex items-center justify-center flex-shrink-0">
                      <ChevronRight className="h-3 w-3 text-green-500" />
                    </div>
                    <span className="text-slate-300">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-10 mb-20">
            <div className="bg-slate-800 p-8 rounded-xl">
              <h3 className="text-2xl font-semibold text-white mb-4">Neural Interface</h3>
              <p className="text-slate-300 mb-4">
                Our proprietary technology directly interfaces with taste receptors and neural pathways to enhance and
                modify flavor perception without invasive procedures.
              </p>
              <p className="text-slate-300">
                By targeting specific neural pathways associated with taste perception, we can amplify, modify, or
                create entirely new taste experiences that go beyond the traditional five taste categories.
              </p>
            </div>

            <div className="bg-slate-800 p-8 rounded-xl">
              <h3 className="text-2xl font-semibold text-white mb-4">Taste Mapping</h3>
              <p className="text-slate-300 mb-4">
                We've developed a comprehensive mapping system that identifies and categorizes taste experiences at a
                granular level, allowing for precise manipulation and enhancement.
              </p>
              <p className="text-slate-300">
                Our AI algorithms learn from individual preferences and physiological responses to create personalized
                taste profiles that evolve over time.
              </p>
            </div>
          </div>

          <div className="bg-slate-800 rounded-2xl p-10 mb-20">
            <h2 className="text-2xl md:text-3xl font-bold text-white mb-6">How It Works</h2>
            <div className="grid md:grid-cols-3 gap-8">
              <div className="bg-slate-900 p-6 rounded-xl">
                <div className="w-12 h-12 bg-green-900/50 rounded-full flex items-center justify-center mb-4 text-xl font-bold text-white">
                  1
                </div>
                <h3 className="text-xl font-semibold text-white mb-3">Sensory Input</h3>
                <p className="text-slate-300">
                  Our device captures data about the food or beverage being consumed, analyzing its molecular
                  composition and flavor profile.
                </p>
              </div>

              <div className="bg-slate-900 p-6 rounded-xl">
                <div className="w-12 h-12 bg-green-900/50 rounded-full flex items-center justify-center mb-4 text-xl font-bold text-white">
                  2
                </div>
                <h3 className="text-xl font-semibold text-white mb-3">Neural Processing</h3>
                <p className="text-slate-300">
                  Our proprietary algorithms translate this data into neural signals that can be interpreted by the
                  brain's taste centers.
                </p>
              </div>

              <div className="bg-slate-900 p-6 rounded-xl">
                <div className="w-12 h-12 bg-green-900/50 rounded-full flex items-center justify-center mb-4 text-xl font-bold text-white">
                  3
                </div>
                <h3 className="text-xl font-semibold text-white mb-3">Enhanced Experience</h3>
                <p className="text-slate-300">
                  The user experiences enhanced or modified taste sensations that complement or transform the original
                  flavor profile.
                </p>
              </div>
            </div>
          </div>

          <div className="text-center">
            <h2 className="text-2xl md:text-3xl font-bold text-white mb-6">Ready to Experience the Future of Taste?</h2>
            <Button asChild className="bg-green-600 hover:bg-green-700 px-8 py-6">
              <a href="/contact">Contact Us</a>
            </Button>
          </div>
        </div>
      </section>
    </main>
  )
}
