import Image from "next/image"
import { Github, Linkedin, Twitter } from "lucide-react"
import { Button } from "@/components/ui/button"

export function TeamSection() {
  const team = [
    {
      name: "Avantika Subudhi",
      role: "Co-Founder & CEO",
      bio: "Neuroscientist with expertise in sensory perception and neural interfaces. Previously led research at top institutions focusing on taste receptor technology.",
      image: "/placeholder.svg?height=400&width=400",
    },
    {
      name: "Suditi Gupta",
      role: "Co-Founder & CTO",
      bio: "Biomedical engineer specializing in neural interface design. Pioneer in developing non-invasive sensory augmentation technologies with multiple patents.",
      image: "/placeholder.svg?height=400&width=400",
    },
  ]

  return (
    <section id="team" className="py-20 bg-slate-900">
      <div className="container">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">Our Team</h2>
          <p className="text-lg text-slate-300">
            Meet the visionaries behind NeuroTaste who are redefining the boundaries of taste perception.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12 max-w-4xl mx-auto">
          {team.map((member, index) => (
            <div key={index} className="flex flex-col items-center">
              <div className="relative w-48 h-48 mb-6">
                <Image
                  src={member.image || "/placeholder.svg"}
                  alt={member.name}
                  fill
                  className="object-cover rounded-full border-4 border-green-500"
                />
              </div>
              <h3 className="text-2xl font-bold text-white mb-1">{member.name}</h3>
              <p className="text-green-400 mb-4">{member.role}</p>
              <p className="text-slate-300 text-center mb-6">{member.bio}</p>
              <div className="flex gap-4">
                <Button
                  variant="ghost"
                  size="icon"
                  className="rounded-full text-slate-300 hover:text-white hover:bg-slate-800"
                >
                  <Linkedin className="h-5 w-5" />
                  <span className="sr-only">LinkedIn</span>
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="rounded-full text-slate-300 hover:text-white hover:bg-slate-800"
                >
                  <Twitter className="h-5 w-5" />
                  <span className="sr-only">Twitter</span>
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="rounded-full text-slate-300 hover:text-white hover:bg-slate-800"
                >
                  <Github className="h-5 w-5" />
                  <span className="sr-only">GitHub</span>
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
