import Link from "next/link"
import { Brain } from "lucide-react"

export function SiteFooter() {
  return (
    <footer className="bg-slate-950 text-slate-400 py-12">
      <div className="container">
        <div className="flex flex-col md:flex-row justify-between items-center mb-8">
          <div className="flex items-center gap-2 mb-4 md:mb-0">
            <Brain className="h-8 w-8 text-green-500" />
            <span className="text-xl font-semibold text-white">NeuroTaste</span>
          </div>
          <nav className="flex flex-wrap justify-center gap-8">
            <Link href="/" className="text-sm hover:text-white transition-colors">
              Home
            </Link>
            <Link href="/about-us" className="text-sm hover:text-white transition-colors">
              About Us
            </Link>
            <Link href="/solution" className="text-sm hover:text-white transition-colors">
              Our Solution
            </Link>
            <Link href="/technology" className="text-sm hover:text-white transition-colors">
              Technology
            </Link>
            <Link href="/research" className="text-sm hover:text-white transition-colors">
              Research
            </Link>
            <Link href="/contact" className="text-sm hover:text-white transition-colors">
              Contact
            </Link>
          </nav>
        </div>
        <div className="border-t border-slate-800 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-sm mb-4 md:mb-0">© {new Date().getFullYear()} NeuroTaste. All rights reserved.</p>
          <div className="flex gap-6">
            <Link href="#" className="text-slate-400 hover:text-white transition-colors">
              Privacy Policy
            </Link>
            <Link href="#" className="text-slate-400 hover:text-white transition-colors">
              Terms of Service
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}
