import Link from "next/link"
import { Brain } from "lucide-react"
import { Button } from "@/components/ui/button"

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-50 w-full border-b border-slate-800 bg-slate-900/80 backdrop-blur-sm">
      <div className="container flex h-20 items-center justify-between">
        <Link href="/" className="flex items-center gap-2">
          <Brain className="h-8 w-8 text-green-500" />
          <span className="text-xl font-semibold text-white">NeuroTaste</span>
        </Link>
        <nav className="hidden md:flex items-center gap-8">
          <Link href="/" className="text-sm font-medium text-slate-300 hover:text-green-400 transition-colors">
            Home
          </Link>
          <Link href="/about-us" className="text-sm font-medium text-slate-300 hover:text-green-400 transition-colors">
            About Us
          </Link>
          <Link href="/solution" className="text-sm font-medium text-slate-300 hover:text-green-400 transition-colors">
            Our Solution
          </Link>
          <Link
            href="/technology"
            className="text-sm font-medium text-slate-300 hover:text-green-400 transition-colors"
          >
            Technology
          </Link>
          <Link href="/research" className="text-sm font-medium text-slate-300 hover:text-green-400 transition-colors">
            Research
          </Link>
        </nav>
        <Button asChild className="bg-green-600 hover:bg-green-700">
          <Link href="/contact">Contact Us</Link>
        </Button>
      </div>
    </header>
  )
}
